import sqlite3
import hashlib
import tkinter as tk
from tkinter import messagebox, ttk

# Initialize the database
def initialize_db():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE,
            password TEXT
        )
    ''')

    # Create products table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            name TEXT,
            quantity INTEGER,
            price REAL
        )
    ''')

    conn.commit()
    conn.close()

# Password hashing
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Register user
def register_user(username, password):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hash_password(password)))
        conn.commit()
        messagebox.showinfo("Success", "User registered successfully!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Username already exists.")
    finally:
        conn.close()

# Authenticate user
def authenticate_user(username, password):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('SELECT password FROM users WHERE username = ?', (username,))
    result = cursor.fetchone()

    conn.close()

    if result and result[0] == hash_password(password):
        return True
    return False

# Add product
def add_product(name, quantity, price):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO products (name, quantity, price) VALUES (?, ?, ?)', (name, quantity, price))
    conn.commit()
    conn.close()

# Edit product
def edit_product(product_id, name, quantity, price):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('UPDATE products SET name = ?, quantity = ?, price = ? WHERE id = ?', (name, quantity, price, product_id))
    conn.commit()
    conn.close()

# Delete product
def delete_product(product_id):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
    conn.commit()
    conn.close()

# Low stock alert
def low_stock_alert(threshold):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM products WHERE quantity < ?', (threshold,))
    low_stock_items = cursor.fetchall()

    conn.close()

    return low_stock_items

# GUI Application
class InventoryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Inventory Management System")

        self.login_frame = tk.Frame(self.root)
        self.inventory_frame = tk.Frame(self.root)

        self.create_login_frame()

    def create_login_frame(self):
        self.login_frame.pack(fill="both", expand=True)

        tk.Label(self.login_frame, text="Username").grid(row=0, column=0, padx=10, pady=10)
        self.username_entry = tk.Entry(self.login_frame)
        self.username_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(self.login_frame, text="Password").grid(row=1, column=0, padx=10, pady=10)
        self.password_entry = tk.Entry(self.login_frame, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(self.login_frame, text="Login", command=self.login).grid(row=2, column=0, columnspan=2, pady=10)
        tk.Button(self.login_frame, text="Register", command=self.register).grid(row=3, column=0, columnspan=2, pady=10)

    def create_inventory_frame(self):
        self.login_frame.pack_forget()
        self.inventory_frame.pack(fill="both", expand=True)

        tk.Label(self.inventory_frame, text="Product Name").grid(row=0, column=0, padx=10, pady=10)
        self.product_name_entry = tk.Entry(self.inventory_frame)
        self.product_name_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(self.inventory_frame, text="Quantity").grid(row=1, column=0, padx=10, pady=10)
        self.quantity_entry = tk.Entry(self.inventory_frame)
        self.quantity_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(self.inventory_frame, text="Price").grid(row=2, column=0, padx=10, pady=10)
        self.price_entry = tk.Entry(self.inventory_frame)
        self.price_entry.grid(row=2, column=1, padx=10, pady=10)

        tk.Button(self.inventory_frame, text="Add Product", command=self.add_product).grid(row=3, column=0, columnspan=2, pady=10)
        tk.Button(self.inventory_frame, text="View Low Stock", command=self.view_low_stock).grid(row=4, column=0, columnspan=2, pady=10)

        self.product_tree = ttk.Treeview(self.inventory_frame, columns=("ID", "Name", "Quantity", "Price"), show="headings")
        self.product_tree.heading("ID", text="ID")
        self.product_tree.heading("Name", text="Name")
        self.product_tree.heading("Quantity", text="Quantity")
        self.product_tree.heading("Price", text="Price")
        self.product_tree.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        self.load_products()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if authenticate_user(username, password):
            self.create_inventory_frame()
        else:
            messagebox.showerror("Error", "Invalid username or password")

    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if username and password:
            register_user(username, password)
        else:
            messagebox.showerror("Error", "Please fill out both fields")

    def add_product(self):
        name = self.product_name_entry.get()
        quantity = self.quantity_entry.get()
        price = self.price_entry.get()

        if name and quantity.isdigit() and price:
            add_product(name, int(quantity), float(price))
            messagebox.showinfo("Success", "Product added successfully")
            self.load_products()
        else:
            messagebox.showerror("Error", "Please enter valid data")

    def view_low_stock(self):
        threshold = 5  # You can change this value as needed
        low_stock_items = low_stock_alert(threshold)
        if low_stock_items:
            messagebox.showinfo("Low Stock Alert", f"Low stock items: {low_stock_items}")
        else:
            messagebox.showinfo("Low Stock Alert", "No low stock items")

    def load_products(self):
        for row in self.product_tree.get_children():
            self.product_tree.delete(row)

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM products')
        products = cursor.fetchall()
        conn.close()

        for product in products:
            self.product_tree.insert("", "end", values=product)

if __name__ == "__main__":
    initialize_db()

    root = tk.Tk()
    app = InventoryApp(root)
    root.mainloop()
